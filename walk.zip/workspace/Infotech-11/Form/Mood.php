<?php
$mood = $_REQUEST["feeling"];
?>

<body>
    <div>
        <?php
        if ($mood == "good") {
            echo "<font color='green'>It's good to see your feeling well</font>";
        }
        if ($mood == "okay") {
            echo "<font color='black'>Well that's not great but feel better</font>";
        }
        if ($mood == "bad") {
            echo "<font color='red'>Well that's a shame, get over it</font>";
        }
        
        ?>
    </div>
</body>