<?php
$username = $_REQUEST["username"];
$password = $_REQUEST["password"];
?>
<script> 
function submitmood() {
  document.getElementById('Mood').submit()
}
</script>

<body>
    <div>
        <?php echo $username; ?>,<br>
        <?php
            if ($username == "Matthew") {
                if ($password == "1234") {
                echo "It is very good to see you again!
                    <br><br>
                    <form id='Mood' method='post' action='Mood.php'>
                    <b>How Are you doing doing today?:</b> <br>
                    <input type='radio' name='feeling' value='good'>Good<br>
                    <input type='radio' name='feeling' value='okay'>Okay<br>
                    <input type='radio' name='feeling' value='bad'>Bad<br><br>
                    <input type='button' value='Submit' onclick='submitmood()'><br>
                    </form>
                    </div>";
                } else {
                echo "<font color='red'>Wrong Password</font>";
                }
            }    
            else {
                echo "<font color='red'>Your username is not in the database<font>";
            }
        