<?php 
$choice = $_GET['choice'];

echo "<style>";
echo "  .1  {";
echo "     color:red;";
echo "   }";
echo "  .2  {";
echo "     color:blue;";
echo "   }";
echo "</style>";

?>

<?php 
switch ($choice) {
    case "1" :
            echo "<div class='1'>this is red</div>";
        break;
    case "2" :
            echo "<div class='2'>you chose blue</div>";
        break;
    case "3" :
            echo "this is 3";
        break;
    case "4" :
            echo "this is 4";
        break;
}





?>